// NOM    : 
// PRENOM :

#ifndef __gangster_hpp__
#define __gangster_hpp__

#endif
